This repository contains a simple react/JSv3 hello world application with login service provided by cognito.
The original code is from AWS SDK document example.