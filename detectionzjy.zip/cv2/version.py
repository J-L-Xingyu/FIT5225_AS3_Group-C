opencv_version = "4.9.0.80"
contrib = False
headless = True
rolling = False
ci_build = True