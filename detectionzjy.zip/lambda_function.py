import boto3
import cv2
import numpy as np
import os
import json
import logging

# 配置日志
logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ImageTags')


def lambda_handler(event, context):
    try:
        # 从事件中获取缩略图的Bucket名称和文件名
        thumbnail_bucket = event['Records'][0]['s3']['bucket']['name']
        thumbnail_key = event['Records'][0]['s3']['object']['key']

        logger.info(f"Thumbnail bucket: {thumbnail_bucket}, key: {thumbnail_key}")

        # 推导原始图片的Bucket名称和文件名
        original_bucket = 'iamge-upload-asz'
        original_key = thumbnail_key

        logger.info(f"Original bucket: {original_bucket}, key: {original_key}")

        # 下载原始图片
        download_path = f"/tmp/{os.path.basename(original_key)}"
        s3_client.download_file(original_bucket, original_key, download_path)

        # 使用OpenCV读取原始图片
        image = cv2.imread(download_path)
        if image is None:
            raise Exception(f"Failed to read image from {download_path}")

        # 使用YOLO进行对象检测
        tags = yolo_detect_objects(image)

        # 获取图片的URL
        image_url = f'https://{original_bucket}.s3.amazonaws.com/{original_key}'
        thumbnail_url = f'https://{thumbnail_bucket}.s3.amazonaws.com/{thumbnail_key}'
        notify_subscribers(tags, image_url)
        # 将标签和URL存储到DynamoDB
        table.put_item(Item={'image_url': image_url, 'thumbnail_url': thumbnail_url, 'tags': tags})

        return {'statusCode': 200, 'body': 'Success'}

    except Exception as e:
        logger.error(f"Error processing file: {str(e)}")
        raise e
sns_topics=["person","car","bus"]
def notify_subscribers(tags_detected, image_url):
    sns_client = boto3.client('sns')
    for tag in tags_detected:
        # 假设我们有一个字典，映射标签到 SNS 主题 ARN
        if tag in sns_topics:
            sns_client.publish(
                TopicArn="arn:aws:sns:us-east-1:187701342705:"+tag,
                Message=f'New image with tag {tag}: {image_url}',
                Subject=f'Image Update Notification for {tag}'
            )
def yolo_detect_objects(image):
    yolo_config_bucket = 'yolo-configzz'
    s3_client.download_file(yolo_config_bucket, 'yolov3-tiny.cfg', '/tmp/yolov3-tiny.cfg')
    s3_client.download_file(yolo_config_bucket, 'yolov3-tiny.weights', '/tmp/yolov3-tiny.weights')
    s3_client.download_file(yolo_config_bucket, 'coco.names', '/tmp/coco.names')
    # 加载类别名称
    classes = []
    with open('/tmp/coco.names', 'r') as f:
        classes = [line.strip() for line in f.readlines()]

    net = cv2.dnn.readNet('/tmp/yolov3-tiny.weights', '/tmp/yolov3-tiny.cfg')
    layer_names = net.getLayerNames()

    try:
        out_layer_indices = net.getUnconnectedOutLayers()
        if out_layer_indices.ndim > 1:
            out_layer_indices = out_layer_indices.flatten()  # Flatten if it's a 2D array
    except AttributeError:
        # Handle older OpenCV versions that might not support ndim
        out_layer_indices = [layer[0] for layer in out_layer_indices] if isinstance(out_layer_indices[0],
                                                                                    list) else out_layer_indices

    output_layers = [layer_names[index - 1] for index in out_layer_indices]

    blob = cv2.dnn.blobFromImage(image, 0.00392, (416, 416), (0, 0, 0), True, crop=False)
    net.setInput(blob)
    outs = net.forward(output_layers)

    # 解析检测结果
    tags = []
    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.5:  # 设置一个阈值
                tags.append(classes[class_id])
    return tags
